<?php
return [
    'welcome' => 'Bienvenue dans notre agence de tourisme !',
    'contact' => 'Contactez-nous',
    'about' => 'À propos de nous',
];

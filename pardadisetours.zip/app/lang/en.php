<?php
return [
    'welcome' => 'Welcome to our tourism agency!',
    'contact' => 'Contact Us',
    'about' => 'About Us',
];
<?php include 'templates/header.php'; ?>


<form action="/en/subscribe" method="post">
    <p><input type="text" name="email" placeholder="Votre email"></p>
    <input type="submit" value="Send">
</form>

<?php include 'templates/footer.php'; ?>
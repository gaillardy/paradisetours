
<?php
return [
    'db_host' => 'localhost',
    'db_name' => 'tourism',
    'db_user' => 'root',
    'db_pass' => '',
];
